package com.cybage.qualitymanagement.dto;

public class TestCaseDto {
	
	String title;
	String Description;

}
