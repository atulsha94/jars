package com.cybage.qualitymanagement.dao.impl;

import java.util.ArrayList;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cybage.qualitymanagement.model.TestPlanModel;

@Repository
public class TestCaseDaoImpl {

	@Autowired
	SessionFactory sf;

	@Autowired
	HibernateTemplate hibernateTemplate;

	public ArrayList<String> getTestPlanTitles() {
		@SuppressWarnings("unchecked")
		ArrayList<String> c = (ArrayList<String>) sf.getCurrentSession()
				.createQuery("select c.testPlanTitle from TestPlanModel c").list();
		System.out.println(c);
		return c;

	}

}
