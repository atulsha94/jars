package com.cybage.qualitymanagement.service;

import java.util.ArrayList;

import com.cybage.qualitymanagement.model.TestPlanModel;

public interface TestCaseService {
	public ArrayList<String> getTestPlanTitles();
	
}
