package com.cybage.qualitymanagement.dao;

import com.cybage.qualitymanagement.model.TestPlanModel;

public interface TestPlanDao {

	TestPlanModel addTestPlan(TestPlanModel testPlan);
	TestPlanModel getTestPlan();
}
