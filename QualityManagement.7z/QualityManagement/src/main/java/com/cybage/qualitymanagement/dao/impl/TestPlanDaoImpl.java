package com.cybage.qualitymanagement.dao.impl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cybage.qualitymanagement.dao.TestPlanDao;
import com.cybage.qualitymanagement.model.TestPlanModel;


@Repository
public class TestPlanDaoImpl implements TestPlanDao {
	
	@Autowired
	SessionFactory sf;
	
	@Autowired
	HibernateTemplate hibernateTemplate;
	
	public TestPlanDaoImpl() {
	System.out.println("in dao impl");
	}
	
	@Override
	public TestPlanModel addTestPlan(TestPlanModel testPlanModel){
		 sf.getCurrentSession().save(testPlanModel);
		 
		 return testPlanModel;
	}
	
	@Override
	public TestPlanModel getTestPlan() {
		/*
		 * @SuppressWarnings("unchecked") ArrayList<String>
		 * c=(ArrayList<String>) sf.getCurrentSession() .createQuery(
		 * "select c.testPlanTitle from TestPlan c") .list(); return c;
		 */
		TestPlanModel testPlanModel = (TestPlanModel) hibernateTemplate.get(TestPlanModel.class, 1);
		return testPlanModel;
	}
}
