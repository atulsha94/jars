package com.cybage.qualitymanagement.service;

import com.cybage.qualitymanagement.model.TestPlanModel;

public interface TestPlanService {

	TestPlanModel addTestPlan(TestPlanModel testPlan);
	
	TestPlanModel getTestPlan();
}
