package com.cybage.qualitymanagement.service.impl;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.qualitymanagement.dao.impl.TestCaseDaoImpl;
import com.cybage.qualitymanagement.model.TestPlanModel;
import com.cybage.qualitymanagement.service.TestCaseService;



@Service
@Transactional
public class TestCaseServiceImpl implements TestCaseService {

	@Autowired
	TestCaseDaoImpl testCaseDaoImpl;
	
	@Override
	public ArrayList<String> getTestPlanTitles() {
		System.out.println(testCaseDaoImpl.getTestPlanTitles());
		return testCaseDaoImpl.getTestPlanTitles();
	}
	

	
}
